const body = document.body;
const themeToggle = document.querySelector('#theme-toggle');
const themeIcon = document.querySelector('#theme-icon');
const menuToggle = document.querySelector('#menu-toggle');
const navLinks = document.querySelector('#nav-links');
const dialog = document.querySelector('#project-dialog');
const dialogTitle = document.querySelector('#dialog-title');
const dialogDescription = document.querySelector('#dialog-description');
const dialogTags = document.querySelector('#dialog-tags');
const dialogClose = document.querySelector('#dialog-close');

const projectDetails = {
  myproject: {
    title: 'My Project',
    description: 'A project repository shared by Lakshya Sharma. Visit the GitHub repository to inspect its actual contents and purpose.',
    tags: ['GitHub', 'Personal project']
  },
  prompt20: {
    title: 'Prompt 20',
    description: 'This project name was provided, but a description and repository URL were not. Add accurate project details and a verified link before sharing it as a completed project.',
    tags: ['Details to be added']
  },
  portfolio: {
    title: 'Developer Portfolio',
    description: 'This portfolio presents Lakshya Sharma’s education, learning areas, contact links, and project information. It includes responsive layout, a light/dark theme toggle, mobile navigation, and project detail dialogs.',
    tags: ['HTML5', 'CSS3', 'JavaScript', 'Responsive design']
  }
};

function setTheme(theme) {
  const light = theme === 'light';
  body.classList.toggle('light-theme', light);
  themeIcon.textContent = light ? '☾' : '☼';
  themeToggle.setAttribute('aria-label', light ? 'Switch to dark theme' : 'Switch to light theme');
  document.querySelector('meta[name="theme-color"]').setAttribute('content', light ? '#f8f9fc' : '#10131f');
  try { localStorage.setItem('portfolio-theme', theme); } catch (_) { /* Theme still works if storage is unavailable. */ }
}

let savedTheme = 'dark';
try { savedTheme = localStorage.getItem('portfolio-theme') || 'dark'; } catch (_) { /* Use dark theme by default. */ }
setTheme(savedTheme);
themeToggle.addEventListener('click', () => setTheme(body.classList.contains('light-theme') ? 'dark' : 'light'));

menuToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
});
navLinks.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  navLinks.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Open navigation menu');
}));

document.querySelectorAll('[data-project]').forEach(button => {
  button.addEventListener('click', () => {
    const project = projectDetails[button.dataset.project];
    if (!project) return;
    dialogTitle.textContent = project.title;
    dialogDescription.textContent = project.description;
    dialogTags.replaceChildren(...project.tags.map(tag => {
      const span = document.createElement('span');
      span.textContent = tag;
      return span;
    }));
    dialog.showModal();
  });
});

dialogClose.addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => {
  if (event.target === dialog) dialog.close();
});
document.querySelector('#year').textContent = new Date().getFullYear();

// A subtle entrance effect; content remains visible if IntersectionObserver is unavailable.
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('reveal');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.section-heading, .about-card, .stat-card, .skill-card, .project-card, .resume-panel, .contact-panel').forEach(el => observer.observe(el));
}
