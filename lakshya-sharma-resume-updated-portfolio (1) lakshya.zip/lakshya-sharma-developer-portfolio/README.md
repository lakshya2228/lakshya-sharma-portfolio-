# Lakshya Sharma — Developer Portfolio

A responsive personal portfolio website for Lakshya Sharma, a Python Developer Intern and aspiring software engineer based in Jaipur, Rajasthan. Built with semantic HTML5, CSS3, and vanilla JavaScript.

## Features

- Responsive layout for mobile, tablet, and desktop
- Dark/light theme toggle (preference saved in local storage)
- Mobile navigation menu
- Smooth section navigation and accessible skip link
- About, skills, projects, downloadable resume, and contact sections
- Project details dialogs
- No framework or build step required

## Technologies

- HTML5
- CSS3 (Flexbox, Grid, responsive media queries)
- JavaScript (ES6+)
- GitHub and Vercel for source control and deployment

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Alternatively, open the folder in Visual Studio Code and use the Live Server extension.

## Personal details used

- **Name:** Lakshya Sharma
- **Role:** Python Developer Intern | Aspiring Software Engineer
- **Education:** CBSE Senior Secondary (Class XII), Commerce + Informatics Practices, 2026
- **Location:** Jaipur, Rajasthan
- **Technical skills:** Core Python, OOP, DSA, NumPy, Pandas, Matplotlib, OS module, MySQL (basic), CRUD operations, VS Code, IDLE, Git (beginner)
- **GitHub:** https://github.com/lakshya2228
- **LinkedIn:** https://www.linkedin.com/in/lakshya-sharma
- **Email:** lakshyasharma1137@gmail.com

## Before submitting

1. Review all content and make sure it accurately describes you.
2. The `My Project` card links to the GitHub URL you supplied. Check that the repository is public and that its README explains the project.
3. The `Prompt 20` card is marked as incomplete because no description or URL was supplied. Add the real details before submission, or remove the card if it is not a project.
4. The real resume PDF is included at `assets/Lakshya_Sharma_Resume.pdf` and linked from the resume button. Confirm the email address and phone number in your resume are current before publishing.
5. Verify your email, GitHub, and LinkedIn links.
6. After uploading this portfolio to a new GitHub repository, update the portfolio project card with that repository URL if desired.

## Deploy on Vercel

1. Create a new **public** GitHub repository (for example, `lakshya-developer-portfolio`).
2. Upload the contents of this project folder to the repository root.
3. Sign in to Vercel with GitHub and choose **Add New → Project**.
4. Import the new portfolio repository. For this static HTML project, no framework or build command is required.
5. Deploy, open the generated URL, and test the website on desktop and mobile.
6. Add the final live URL to this README.

## Live demo

Not deployed yet. Add the Vercel URL after deployment.

## Author

Lakshya Sharma — https://github.com/lakshya2228


## Visual design update
This version uses a more expressive blue/cyan visual identity, subtle dotted hero background, animated decorative orbits, richer project cards, hover states, and enhanced section styling. The layout remains responsive and includes reduced-motion support.

Before submitting, verify all project details and add your actual resume PDF to the `assets` folder if you want a working resume download.
